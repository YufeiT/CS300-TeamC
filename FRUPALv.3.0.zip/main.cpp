// ************ MAIN HEADER FILE *****************    
//
// TEAM C: Jordan, Yufei, David, Shannon, Asher
// Frupal 
// CS300
// Jan 28, 2018
//
#include "Map.h"
#include<cctype>

using namespace std;

void clear();
void shopdisplay();
void displayLegend();


int main()
{
    //Set srand seed
    srand(time(NULL));

    Tile* theTile = NULL;
    char userCommand = ' ';
    int menuCommand;
    bool noEnergy = false;
    bool jewel = false;
    bool ready = false;
    bool check_input = false;
    

    //Default game variables for settings
    int startingEnergy = 50;
    int startingMoney = 40;
    int mapChoice = 3;
    int numOfObs = 10;
    bool save = false;
    shop myShop;

  //  struct configs

    //SETTINGS/PLAY LOOP
    do{
        cout<< yellow << "----Welcome to Frupal----\n" << reset;
        cout<<"1. Play game\n";
        cout<<"2. Settings\n";
        cout<<"3. Quit\n";
        cout<< yellow << "-------------------------\n" << reset; 
        cout<< "Input: ";
        cin >> menuCommand; cin.ignore(100,'\n');

        //checking input
        while(menuCommand > 3 || menuCommand < 1){
            cout << "Invalid command, please re-enter: ";
            cin >> menuCommand;
            cin.ignore(100, '\n');
            cout << endl;
        }
        //Play
        if(menuCommand == 1){
            ready = true;
        }
        //Settings
        if(menuCommand == 2){
          do{
            int select = 0;
            cout << yellow << "~~~~~~~~~ CURRENT SETTINGS ~~~~~~~~~~~\n";
            cout<<"Player energy\t\tdefault:50 \tcurrent:"<<startingEnergy<<"\n";
            cout<<"Player money\t\tdefault:40 \tcurrent:"<<startingMoney<<"\n";
            cout<<"Map selection\t\tdefault:3 \tcurrent:"<<mapChoice<<"\n";
            cout<<"Number of obstacles \tdefault:10 \tcurrent:"<<numOfObs<<"\n";
            cout << reset;
            myShop.display();
            do{
              cout <<" 1. Player energy and money\n";
              cout <<" 2. Map size\n";
              cout <<" 3. Number of obstacles\n";
              cout <<" 4. Item prices and energy bar\n";
              cout <<" 5. Save and return to main menu\n";
              cout <<"Enter number of the game setting to be changed: ";
              cin >> select; cin.ignore(100,'\n');
            }while(select < 1 && select > 5);
            switch(select){
            case 1:
              cout << "Energy: ";
              cin>>startingEnergy; cin.ignore(100,'\n');
              cout << "Money: ";
              cin>>startingMoney; cin.ignore(100,'\n');
              break;
            case 2:
              cout<<"Large = 3; Medium = 2; Small = 1\nnew:";
              cin>>mapChoice; cin.ignore(100,'\n');
              break;
            case 3:
              cout<<"Number of obstacles on map: "; 
              cin>>numOfObs; cin.ignore(100,'\n');
              break;
            case 4:
              myShop.set_price();
              break;
            case 5:
              save = true;
              break;
            default:
              save = true;
            }
          }while(!save);
        }
        //Quit
        if(menuCommand == 3){
            return 1;
        }
    }while(!ready);

    //Initialize variables/objects
    player myHero(startingMoney,startingEnergy);
    Map gameMap(mapChoice,numOfObs);

    //MAIN GAME LOOP
    do{   
        //Clear the screen
        clear();

        //Display map, player info, and controls
        displayLegend();
        gameMap.update(myHero.hasBinos());
        gameMap.display();
        myHero.display_inv(); 
        gameMap.clues();
        cout << yellow << "|ENERGY: " << myHero.getEnergy() << "| " << reset;
        cout << green  << "|MONEY: " << "$" << myHero.getMoney() << "|" << reset << endl;
        cout << cyan << "\n To enter the shop (i)\n" << reset;
        cout << red << " To move enter direction (w,a,s,d)\n\n" << reset;

        cout << "User command: ";
        cin >> userCommand; cin.ignore(100,'\n');
        //input error checking
        check_input = gameMap.checkInput(userCommand);
        while(check_input == false){
            cin >> userCommand;
            cin.clear();
            cin.ignore(100,'\n');
            check_input = gameMap.checkInput(userCommand);
        }

        if(userCommand == 'i')
        {
            myShop.display(); 
            if(myShop.purchase(&myHero) < 0)
                gameMap.addToRecord("Insufficient funds for purchase!");
            else
                gameMap.addToRecord("Purchase success!");
        }
        else if(userCommand == 'C'){
            jewel = true;
            cout << string(100, '\n');
            gameMap.reveal_map();
            cout << magenta << "~~~~~ YOU WIN ~~~~~" << reset << endl;
        }
        else
        {
            //Bounds check and put the Tile to move to in theTile
            if(gameMap.getTileToMoveTo(userCommand,theTile)){
                //Check for water/obstacles
                if(myHero.tryToMoveTo(theTile)){
                    gameMap.movePlayer(userCommand);
                    gameMap.addToRecord("Movement success!");
                }
                else{
                    
                    gameMap.addToRecord("Cannot move into water w/o a boat!");
                }
            }
            //We were moving out of bounds so print error and resume
            else{
                gameMap.addToRecord("Movement out of bounds!");
            }

            //Out of energy, game over!
            if(gameMap.gotJewel()){
                jewel = true;
                gameMap.addToRecord("Game victory!");
                cout << magenta << "~~~~~ YOU WIN ~~~~~" << reset << endl;
            }
            else{
                if(myHero.getEnergy() <= 0){
                    noEnergy = true;
                    cout << yellow << "|ENERGY: " << myHero.getEnergy() << "| " << reset;
                    cout << green  << "|MONEY: " << "$" << myHero.getMoney() << "|" << reset << "\n\n\n\n";
                    gameMap.addToRecord("You lose!");
                    cout << red << "~~~~~GAME OVER~~~~~" << reset << endl;
                }
            }
        }
      //  gameMap.update(myHero.hasBinos());
    }while(!noEnergy && !jewel);

    return 0;
}

// Clears screen by printing 50 lines
void clear()
{
    for(int i=0; i<50; ++i)
    {
        cout << endl;
    }
}

// Displays legend for map
void displayLegend(){
    cout<<"------LEGEND------\n";
    cout<<green<<'^'<<reset<<" : Forest\n";
    cout<<magenta<<'='<<reset<<" : Bog\n";
    cout<<yellow<<'-'<<reset<<" : Plains\n";
    cout<<cyan<<'~'<<reset<<" : Water\n";
    cout<<green<<'T'<<reset<<" : Tree Obstacle\n";
    cout<<yellow<<'R'<<reset<<" : Rock Obstacle\n";
    cout<<red<<'B'<<reset<<" : Bush Obstacle\n";
    cout<< 'O' << " : Hero\n\n";
}
