// ************ MAIN HEADER FILE *****************    
//
// Jordan L Co 
// Frupal 
// CS300
// Jan 28, 2018
//
#include "Map.h"
#include<cctype>

using namespace std;

void clear();
void shopdisplay();
int bought();
bool isObstacle(char playerTile);
void displayLegend();

//bool commandCheck(char userCommand);

int main()
{
/*
  shop test;
  test.display(); 
  cout << endl;

  test.set_price();
  test.display(); 
  cout << endl;
*/
	//Set srand seed
  	srand(time(NULL));


	Tile* theTile = NULL;
  	char userCommand = ' ';
  	bool noEnergy = false;
  	bool jewel = false;
	bool ready = false;

	//Variables for settings
	int startingEnergy = 30;
	int startingMoney = 20;
	int mapChoice = 3;
	int numOfObs = 10;
	float shopMultiplier = 1;
  	shop myShop;

	//SETTINGS/PLAY LOOP
	do{
		std::cout<<"----Welcome to Frupal----\n\n";
		std::cout<<"1. Play game\n";
		std::cout<<"2. Settings\n";
		std::cout<<"3. Quit\n";
		cin >> userCommand; cin.ignore(100,'\n');
		//Play
		if(userCommand == '1' || userCommand == 'p' || userCommand == 'P'){
			ready = true;
		}
		//Settings
		if(userCommand == '2' || userCommand == 's' || userCommand == 'S'){
			cout<<"Player starting energy (default:30, current:"<<startingEnergy<<"\nnew:";
			cin>>startingEnergy; cin.ignore(100,'\n');
			cout<<"Player starting money (default:20, current:"<<startingMoney<<"\nnew:";
			cin>>startingMoney; cin.ignore(100,'\n');
			cout<<"Map selection (default:3, current:"<<mapChoice<<"\n";
			cout<<"Large = 3; Medium = 2; Small = 1\nnew:";
			cin>>mapChoice; cin.ignore(100,'\n');
			cout<<"Number of obstacles (default:10, current:"<<numOfObs<<"\nnew:";
			cin>>numOfObs; cin.ignore(100,'\n');
			myShop.set_price();
			//cout<<"Shop price multiplier (default:1, current:"<<shopMultiplier<<"\nnew:";
			//cin>>shopMultiplier; cin.ignore(100,'\n');
		}
		//Quit
		if(userCommand == '3' || userCommand == 'q' || userCommand == 'Q'){
			return 1;
		}
	}while(!ready);

	//Initialize variables/objects
  	player myHero(startingMoney,startingEnergy);
  	Map gameMap(mapChoice,numOfObs);
  
  	gameMap.update(false);
	//MAIN GAME LOOP
  	do{   
  		//Clear the screen
    	clear();

		//Display map, player info, and controls
    	displayLegend();
		gameMap.display();
    	myHero.display_inv(); 
    	cout << yellow << "|ENERGY: " << myHero.getEnergy() << "| " << reset;
    	cout << green  << "|MONEY: " << "$" << myHero.getMoney() << "|" << reset << endl;
    	cout << cyan << "\n To enter the shop (i)\n" << reset;
    	cout << red << " To move enter direction (w,a,s,d)\n\n" << reset;
	
	    // Add try catch block for user input 
	    cout << "User command: ";
	    cin >> userCommand; cin.ignore(100,'\n');
	    if(userCommand == 'i')
	    {
	    	myShop.display(); 
       		if(myShop.purchase(&myHero) < 0)
        		gameMap.addToRecord("Insufficient funds for purchase!");
			else
				gameMap.addToRecord("Purchase success!");
    	}
    	else
    	{
			//Bounds check and put the Tile to move to in theTile
			if(gameMap.getTileToMoveTo(userCommand,theTile)){
				//Check for water/obstacles
				if(myHero.tryToMoveTo(theTile)){
					gameMap.movePlayer(userCommand);
					gameMap.addToRecord("Movement success!");
				}
				else{
					gameMap.addToRecord("Cannot move into water w/o a boat!");
				}
			}
			//We were moving out of bounds so print error and resume
			else{
				gameMap.addToRecord("Movement out of bounds!");
			}
		
			//Out of energy, game over!
			if(gameMap.gotJewel()){
      			jewel = true;
				gameMap.addToRecord("Game victory!");
      			cout << magenta << "~~~~~ YOU WIN ~~~~~" << reset << endl;
    		}
			else{
    			if(myHero.getEnergy() <= 0){
      				noEnergy = true;
      				cout << yellow << "|ENERGY: " << myHero.getEnergy() << "| " << reset;
      				cout << green  << "|MONEY: " << "$" << myHero.getMoney() << "|" << reset << "\n\n\n\n";
					gameMap.addToRecord("You lose!");
      				cout << red << "~~~~~GAME OVER~~~~~" << reset << endl;
    			}
			}
		}
    	gameMap.update(myHero.hasBinos());
  	}while(!noEnergy && !jewel);

  	return 0;
}

void clear()
{
    for(int i=0; i<50; ++i)
    {
      cout << endl;
    }
}

void shopdisplay()
{
  cout << "***********************************************" << endl;
  cout << "*************** " << cyan << "SHOP " << reset << "***************";
  cout << "\n Please enter the number of the item you wish to purchase \n";
  cout << " 1. Boat                  $20\n";
  cout << " 2. Weedwacker            $10\n";
  cout << " 3. Chainsaw              $10\n";;
  cout << " 4. Jackhammer            $10\n";
  cout << " 5. Energy Bar            $5\n";
  cout << " 6. Binoculars            $5\n\n";
}

int bought()
{
  int item;
  cout << "Item #: ";
  cin >> item; cin.ignore(100,'\n');
  if(item < 1 || item > 6)
    return -1;
  return item;
}

//Checks if the tile is an obstacle
bool isObstacle(char playerTile){
  if(playerTile == 'M' || playerTile == 'T' || playerTile == 'W')
      return true;
  return false;
}

void displayLegend(){
	cout<<"------LEGEND------\n";
	cout<<green<<'^'<<reset<<" : Forest\n";
	cout<<magenta<<'='<<reset<<" : Bog\n";
	cout<<yellow<<'-'<<reset<<" : Plains\n";
	cout<<cyan<<'~'<<reset<<" : Water\n";
	cout<<green<<'T'<<reset<<" : Tree Obstacle\n";
	cout<<yellow<<'R'<<reset<<" : Rock Obstacle\n";
	cout<<red<<'B'<<reset<<" : Bush Obstacle\n";
}
